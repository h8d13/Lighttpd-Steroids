# Lighttpd-Steroids
My best attempt at making lighttpd modern again!
